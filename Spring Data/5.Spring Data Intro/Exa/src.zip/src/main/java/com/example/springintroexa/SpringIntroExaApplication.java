package com.example.springintroexa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringIntroExaApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringIntroExaApplication.class, args);


    }

}
