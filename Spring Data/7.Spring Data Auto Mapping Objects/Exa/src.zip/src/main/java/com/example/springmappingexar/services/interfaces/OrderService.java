package com.example.springmappingexar.services.interfaces;

public interface OrderService {
    void addGameToUser(String title);

    void removeItem(String title);

    void buyItems();
}
