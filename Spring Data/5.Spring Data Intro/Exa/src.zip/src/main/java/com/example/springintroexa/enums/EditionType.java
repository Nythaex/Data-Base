package com.example.springintroexa.enums;

public enum EditionType {
    NORMAL,PROMO,GOLD
}
