package com.example.springintroexa.enums;

public enum AgeRestriction {
    MINOR,TEEN,ADULT;
}
