package com.example.springintroexa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringIntroExaApplicationTests {

    @Test
    void contextLoads() {
    }

}
