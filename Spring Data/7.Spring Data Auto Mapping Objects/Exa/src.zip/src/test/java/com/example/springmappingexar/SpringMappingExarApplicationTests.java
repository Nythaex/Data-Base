package com.example.springmappingexar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMappingExarApplicationTests {

    @Test
    void contextLoads() {
    }

}
