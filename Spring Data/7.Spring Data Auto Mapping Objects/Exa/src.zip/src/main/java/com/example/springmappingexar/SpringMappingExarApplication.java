package com.example.springmappingexar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMappingExarApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringMappingExarApplication.class, args);
    }

}
